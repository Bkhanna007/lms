from django import forms
from .models import *





# leavetype=[('Work From Home','Work From Home'),
#            ('Sick Leave','Sick Leave'),
#            ('Piad Leave','Piad Leave'),
#            ('Unpaid Leave','Unpaid Leave')


# ]


# class LeaveForm(forms.Form):
#     Leavetype = forms.CharField(label= ' What is your leave type?', widget=forms.Select(choices=leavetype))
#     Startdate = forms.DateField(label= 'DD/MM/YYYYY')
#     Enddate = forms.DateField(label= 'DD/MM/YYYY')
#     Reason = forms.Textarea()


class LeaveForm(forms.ModelForm):
    
     class Meta:

        model=LeaveFormM
        fields='__all__'
  


