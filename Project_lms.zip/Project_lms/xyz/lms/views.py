from django.shortcuts import render
from .forms import  *
from django.shortcuts import render,redirect
from django.http import HttpResponse,HttpResponseRedirect
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import authenticate,login,logout   


# Create your views here.

    
def index (request):
    if request.method == "POST":
        fm=  LeaveForm(request.POST)
        if fm.is_valid:
         fm.save()
         fm=LeaveForm()

    else:

        fm=LeaveForm()

    return render(request,'form.html',{'form':fm})

def showdetails(request):
   leave_details = LeaveFormM.objects.all()
   return render(request,'show.html',{'ld':leave_details})

def showrecord(request):
   leave_details = LeaveFormM.objects.all()
   value={
      'ld':leave_details,
      'status':'pending'

   }
   return render(request,'record.html',value)

def delete(request,id):
#    if request.method=='POST':
    del_rec=LeaveFormM.objects.get(pk=id)
    del_rec.delete()
    return redirect('/show')

def user_login(request):
    if request.method =="POST":
       fm= AuthenticationForm(request=request,data=request.POST)
       if fm.is_valid():
          uname=fm.cleaned_data['username']
          upass=fm.cleaned_data['password']
          user=authenticate(username=uname,password=upass)
          if user is not None:
                login(request, user)
                return HttpResponseRedirect('/show/')
          
    else:
        fm= AuthenticationForm()

        


    return render(request,'userlogin.html',{'form':fm})
   