from django.db import models

leavetypeM=[
    
        ('Work From Home','Work From Home'),
           ('Sick Leave','Sick Leave'),
           ('Piad Leave','Piad Leave'),
           ('Unpaid Leave','Unpaid Leave')
]


class LeaveFormM(models.Model):
    username=models.CharField(max_length=50,default=None)
    password=models.CharField(max_length=50,default=None)
    Leavetype = models.CharField(max_length=50,choices=leavetypeM)
    Startdate = models.DateField()
    Enddate = models.DateField()
    Reason = models.TextField()



