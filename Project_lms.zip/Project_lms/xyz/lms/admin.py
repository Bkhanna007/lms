from django.contrib import admin
from .models import LeaveFormM

@admin.register (LeaveFormM)
class LeaveadminForm(admin.ModelAdmin):
    list_display=['Leavetype','Startdate','Enddate','Reason']
