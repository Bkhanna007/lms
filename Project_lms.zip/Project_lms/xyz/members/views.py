from django.shortcuts import render,redirect,HttpResponseRedirect
from django.contrib.auth import authenticate,login,logout
from django.contrib import messages
from xyz.urls import *


# Create your views here.
def login_user(request):
    if request.method =="POST":
        username = request.POST.get("username")
        password = request.POST.get("password")
        user= authenticate( username=username, password=password)
        if user is not None:
                login(request, user)
                return redirect('/show')
        # Redirect to a success page.
        else:
         return redirect('/leave')
        # Return an 'invalid login' error message.
         

    else:
       return render(request,'login.html',{})